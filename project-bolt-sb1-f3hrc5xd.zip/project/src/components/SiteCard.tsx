import React from 'react';
import { SiteForecast } from '../types/weather';
import { getWindDirection } from '../services/weatherService';
import { Wind, TrendingUp, Mountain, Thermometer, Bird } from 'lucide-react';
import SoaringKiteIcon from './SoaringKiteIcon';

interface SiteCardProps {
  siteForecast: SiteForecast;
  onClick?: () => void;
}

const SiteCard: React.FC<SiteCardProps> = ({ siteForecast, onClick }) => {
  const { site, forecast } = siteForecast;
  const today = forecast[0];

  const getFlyabilityColor = (flyability: string) => {
    switch (flyability) {
      case 'good': return 'text-green-600';
      case 'marginal': return 'text-yellow-600';
      case 'poor': return 'text-red-600';
      default: return 'text-gray-400';
    }
  };

  const getFlyabilityBg = (flyability: string) => {
    const soaring = today.soaringFlyability;
    const thermal = today.thermalFlyability;

    if (soaring === 'good' || thermal === 'good') return 'bg-green-50 border-green-200';
    if (soaring === 'marginal' || thermal === 'marginal') return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  return (
    <div
      className={`rounded-lg border-2 p-4 transition-all hover:shadow-lg cursor-pointer ${getFlyabilityBg(today.flyability)}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-lg font-bold text-gray-900">{site.name}</h3>
          <p className="text-sm text-gray-600">{site.elevation}' MSL • {site.orientation}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex flex-col items-center" title="Soaring (Ridge/Wind)">
            <SoaringKiteIcon className={`w-5 h-5 ${getFlyabilityColor(today.soaringFlyability)}`} />
            <span className="text-xs text-gray-500">Soar</span>
          </div>
          <div className="flex flex-col items-center" title="Thermal Flying">
            <Bird className={`w-5 h-5 ${getFlyabilityColor(today.thermalFlyability)} transform rotate-12`} />
            <span className="text-xs text-gray-500">Thermal</span>
          </div>
        </div>
      </div>

      <div className="mb-3 p-2 bg-white bg-opacity-50 rounded border border-gray-200">
        <div className="text-xs text-gray-600 font-semibold mb-1">Best Launch Time</div>
        <div className="text-lg font-bold text-gray-900">{today.launchTime}</div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-sm">
          <Wind className="w-4 h-4 text-blue-600" />
          <span>{today.windSpeed}mph {getWindDirection(today.windDirection)} (G{today.windGust})</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Thermometer className="w-4 h-4 text-red-600" />
          <span>{today.temperature}°F (TCON: {today.tcon}°F)</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <TrendingUp className="w-4 h-4 text-orange-600" />
          <span>Thermals: {today.thermalStrength}/10</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Mountain className="w-4 h-4 text-purple-600" />
          <span>Useable lift: {today.topOfLift.toLocaleString()}'</span>
        </div>
      </div>

      <div className="text-sm font-medium text-gray-700 mb-3">
        {today.conditions}
        {today.rainInfo && (
          <div className="text-sm text-blue-700 font-semibold mt-1">
            {today.rainInfo}
          </div>
        )}
      </div>

      {forecast.length > 1 && (
        <div className="grid grid-cols-2 gap-2">
          {forecast.map((day, index) => (
            <div key={day.date} className="text-center">
              <div className="text-xs text-gray-500 mb-1">
                {index === 0 ? 'Today' : 'Tomorrow'}
              </div>
              <div className="flex gap-1 justify-center mb-1">
                <SoaringKiteIcon className={`w-3 h-3 ${getFlyabilityColor(day.soaringFlyability)}`} title="Soaring" />
                <Bird className={`w-3 h-3 ${getFlyabilityColor(day.thermalFlyability)} transform rotate-12`} title="Thermal" />
              </div>
              <div className="text-xs">{day.windSpeed}mph • {day.launchTime}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SiteCard;
