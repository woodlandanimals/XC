import React from 'react';
import { Bird } from 'lucide-react';
import SoaringKiteIcon from './SoaringKiteIcon';

const Legend: React.FC = () => {
  const conditions = [
    { color: 'text-green-600', label: 'Good', description: 'Great flying conditions' },
    { color: 'text-yellow-600', label: 'Marginal', description: 'Flyable but challenging' },
    { color: 'text-red-600', label: 'Poor', description: 'Not recommended' }
  ];

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">Conditions Legend</h3>

      <div className="mb-3 pb-3 border-b border-gray-200">
        <div className="text-xs font-semibold text-gray-600 mb-2">Flying Types:</div>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center gap-2">
            <SoaringKiteIcon className="w-4 h-4 text-gray-700" />
            <span className="text-sm font-medium text-gray-700">Soaring</span>
            <span className="text-xs text-gray-500">- Ridge/wind flying</span>
          </div>
          <div className="flex items-center gap-2">
            <Bird className="w-4 h-4 text-gray-700 transform rotate-12" />
            <span className="text-sm font-medium text-gray-700">Thermal</span>
            <span className="text-xs text-gray-500">- Thermal flying</span>
          </div>
        </div>
      </div>

      <div className="mb-3">
        <div className="text-xs font-semibold text-gray-600 mb-2">Condition Ratings:</div>
        <div className="flex flex-wrap gap-4">
          {conditions.map((condition) => (
            <div key={condition.label} className="flex items-center gap-2">
              <Bird className={`w-4 h-4 ${condition.color}`} />
              <span className="text-sm font-medium text-gray-700">{condition.label}</span>
              <span className="text-xs text-gray-500">- {condition.description}</span>
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-gray-500 mt-3">
        * Each site shows two ratings: one for soaring (ridge/wind) and one for thermal flying. Launch times are optimized based on the best available conditions. Forecasts limited to today and tomorrow using high-resolution weather model data via Open-Meteo API. Always verify current conditions.
      </p>
    </div>
  );
};

export default Legend;
