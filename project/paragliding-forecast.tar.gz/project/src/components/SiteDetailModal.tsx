import React from 'react';
import { SiteForecast } from '../types/weather';
import { getWindDirection } from '../services/weatherService';
import {
  X, Wind, Thermometer, TrendingUp, Mountain, Droplets,
  Cloud, Gauge, ArrowUp, Layers, AlertTriangle, CheckCircle2
} from 'lucide-react';

interface SiteDetailModalProps {
  siteForecast: SiteForecast;
  onClose: () => void;
}

const SiteDetailModal: React.FC<SiteDetailModalProps> = ({ siteForecast, onClose }) => {
  const { site, forecast } = siteForecast;

  const getFlyabilityColor = (flyability: string) => {
    switch (flyability) {
      case 'good': return 'text-green-600';
      case 'marginal': return 'text-yellow-600';
      case 'poor': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getFlyabilityBg = (flyability: string) => {
    switch (flyability) {
      case 'good': return 'bg-green-100 border-green-300';
      case 'marginal': return 'bg-yellow-100 border-yellow-300';
      case 'poor': return 'bg-red-100 border-red-300';
      default: return 'bg-gray-100 border-gray-300';
    }
  };

  const getDayLabel = (index: number) => {
    if (index === 0) return 'Today';
    if (index === 1) return 'Tomorrow';
    return `Day ${index + 1}`;
  };

  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{site.name}</h2>
            <p className="text-sm text-gray-600">
              {site.elevation.toLocaleString()}' MSL • {site.orientation} facing • Max wind {site.maxWind}mph
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6">
          {forecast.map((day, index) => (
            <div
              key={day.date}
              className={`mb-6 rounded-lg border-2 p-5 ${getFlyabilityBg(day.flyability)}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{getDayLabel(index)}</h3>
                  <p className="text-sm text-gray-600">{formatDate(day.date)}</p>
                </div>
                <div className="text-right">
                  <div className={`text-lg font-bold ${getFlyabilityColor(day.flyability)} capitalize`}>
                    {day.flyability}
                  </div>
                  {day.windDirectionMatch ? (
                    <div className="flex items-center gap-1 text-green-600 text-sm">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Wind direction good</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-red-600 text-sm">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Wind direction poor</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mb-4 p-3 bg-white bg-opacity-60 rounded-lg">
                <p className="text-sm font-medium text-gray-800">{day.conditions}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">Surface Conditions</h4>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Wind className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Wind: {day.windSpeed}mph {getWindDirection(day.windDirection)}</div>
                      <div className="text-xs text-gray-600">Gusts to {day.windGust}mph</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Thermometer className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Temp: {day.temperature}°F</div>
                      <div className="text-xs text-gray-600">Dew point: {day.dewPoint}°F (spread: {day.temperature - day.dewPoint}°F)</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Droplets className="w-5 h-5 text-cyan-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Humidity: {day.relativeHumidity}%</div>
                      <div className="text-xs text-gray-600">TCON: {day.tcon}°F</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Cloud className="w-5 h-5 text-gray-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Cloud cover: {day.cloudCover}%</div>
                      {day.rainInfo && (
                        <div className="text-xs text-blue-700 font-semibold mt-1">{day.rainInfo}</div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">Soaring Conditions</h4>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <TrendingUp className="w-5 h-5 text-orange-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Thermal strength: {day.thermalStrength}/10</div>
                      <div className="text-xs text-gray-600">CAPE: {day.cape} J/kg</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Mountain className="w-5 h-5 text-purple-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Top of lift: {day.topOfLift.toLocaleString()}'</div>
                      <div className="text-xs text-gray-600">
                        {day.topOfLift > site.elevation
                          ? `${(day.topOfLift - site.elevation).toLocaleString()}' AGL`
                          : 'At launch elevation'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                    <Gauge className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Lifted Index: {day.liftedIndex}</div>
                      <div className="text-xs text-gray-600">
                        {day.liftedIndex && day.liftedIndex < -2 ? 'Unstable' : day.liftedIndex && day.liftedIndex > 2 ? 'Stable' : 'Neutral'}
                      </div>
                    </div>
                  </div>

                  {day.blDepth && (
                    <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                      <Layers className="w-5 h-5 text-teal-600 flex-shrink-0" />
                      <div>
                        <div className="font-medium">Boundary layer: {day.blDepth.toLocaleString()}'</div>
                      </div>
                    </div>
                  )}
                </div>

                {(day.wind850mb || day.wind700mb) && (
                  <div className="md:col-span-2 space-y-3">
                    <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">Upper Level Winds</h4>
                    <div className="grid grid-cols-2 gap-3">
                      {day.wind850mb && (
                        <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                          <ArrowUp className="w-5 h-5 text-blue-500 flex-shrink-0" />
                          <div>
                            <div className="font-medium">850mb (~5000'): {day.wind850mb}mph</div>
                            <div className="text-xs text-gray-600">
                              {day.windDir850mb ? getWindDirection(day.windDir850mb) : 'N/A'}
                            </div>
                          </div>
                        </div>
                      )}
                      {day.wind700mb && (
                        <div className="flex items-center gap-2 text-sm bg-white bg-opacity-60 p-2 rounded">
                          <ArrowUp className="w-5 h-5 text-blue-600 flex-shrink-0" />
                          <div>
                            <div className="font-medium">700mb (~10000'): {day.wind700mb}mph</div>
                            <div className="text-xs text-gray-600">
                              {day.windDir700mb ? getWindDirection(day.windDir700mb) : 'N/A'}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-2">About This Forecast</h4>
            <div className="text-xs text-gray-600 space-y-1">
              <p>• Data from high-resolution weather models via Open-Meteo API</p>
              <p>• Forecast optimized for 12pm launch window</p>
              <p>• TCON is the temperature needed for thermals to reach the LCL (Lifting Condensation Level)</p>
              <p>• CAPE measures convective energy; higher values indicate stronger thermal potential</p>
              <p>• Lifted Index indicates atmospheric stability; negative values suggest thermals</p>
              <p>• Always verify current conditions before flying</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SiteDetailModal;
