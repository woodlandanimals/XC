import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import SiteCard from './components/SiteCard';
import Legend from './components/Legend';
import SiteDetailModal from './components/SiteDetailModal';
import { SiteForecast } from './types/weather';
import { getWeatherForecast } from './services/weatherService';

function App() {
  const [forecasts, setForecasts] = useState<SiteForecast[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [selectedSite, setSelectedSite] = useState<SiteForecast | null>(null);

  const fetchForecasts = async () => {
    try {
      setLoading(true);
      const data = await getWeatherForecast();
      setForecasts(data);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to fetch weather data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchForecasts();
    
    // Auto-refresh every 2 hours - data is cached for 1 hour
    const interval = setInterval(fetchForecasts, 2 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  // Sort by best flying conditions first
  const sortedForecasts = [...forecasts].sort((a, b) => {
    const scoreMap = { good: 3, marginal: 2, poor: 1 };
    const scoreA = scoreMap[a.forecast[0].flyability];
    const scoreB = scoreMap[b.forecast[0].flyability];
    return scoreB - scoreA;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        lastUpdated={lastUpdated} 
        onRefresh={fetchForecasts}
        isLoading={loading}
      />
      
      <main className="max-w-6xl mx-auto px-4 py-6">
        {loading && forecasts.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-gray-600">Loading forecast data...</p>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Today's Best Sites</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sortedForecasts
                  .filter(f => f.forecast[0].flyability === 'good')
                  .map((forecast) => (
                    <SiteCard
                      key={forecast.site.id}
                      siteForecast={forecast}
                      onClick={() => setSelectedSite(forecast)}
                    />
                  ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Tomorrow's Best Sites</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sortedForecasts
                  .filter(f => f.forecast.length > 1 && f.forecast[1].flyability === 'good')
                  .map((forecast) => {
                    // Create a modified forecast object with tomorrow's data as "today"
                    const tomorrowForecast = {
                      ...forecast,
                      forecast: [forecast.forecast[1]] // Show only tomorrow's data
                    };
                    return (
                      <SiteCard
                        key={`tomorrow-${forecast.site.id}`}
                        siteForecast={tomorrowForecast}
                        onClick={() => setSelectedSite(forecast)}
                      />
                    );
                  })}
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">All Sites</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sortedForecasts.map((forecast) => (
                  <SiteCard
                    key={forecast.site.id}
                    siteForecast={forecast}
                    onClick={() => setSelectedSite(forecast)}
                  />
                ))}
              </div>
            </div>
          </>
        )}
        
        <Legend />
        
        <div className="text-center text-xs text-gray-500 mt-8 p-4 bg-white rounded-lg border border-gray-200">
          <p className="mb-2">
            <strong>Disclaimer:</strong> This forecast is for reference only. Always check current conditions,
            weather reports, and consult local pilots before flying. Paragliding involves inherent risks.
          </p>
          <p>
            Data sources: High-resolution weather models via Open-Meteo API. Optimized for 12pm launch window. Click any site for detailed forecast.
          </p>
        </div>
      </main>

      {selectedSite && (
        <SiteDetailModal
          siteForecast={selectedSite}
          onClose={() => setSelectedSite(null)}
        />
      )}
    </div>
  );
}

export default App;